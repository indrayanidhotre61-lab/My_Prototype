// In-memory poll store for the prototype
// In production, this would be backed by a database

export interface Poll {
  id: string
  question: string
  options: string[]
  votes: number[]
  createdAt: Date
}

let polls: Poll[] = [
  {
    id: "demo-1",
    question: "Where should we have the end-of-semester party?",
    options: ["Campus Cafe", "Downtown Rooftop", "Beach House", "Student Union"],
    votes: [12, 24, 18, 8],
    createdAt: new Date("2026-02-15"),
  },
  {
    id: "demo-2",
    question: "Best time for the group study session?",
    options: ["Monday 3 PM", "Wednesday 5 PM", "Friday 2 PM"],
    votes: [15, 22, 10],
    createdAt: new Date("2026-02-16"),
  },
]

export function getPolls(): Poll[] {
  return polls
}

export function getPoll(id: string): Poll | undefined {
  return polls.find((p) => p.id === id)
}

export function createPoll(question: string, options: string[]): Poll {
  const poll: Poll = {
    id: `poll-${Date.now()}`,
    question,
    options,
    votes: options.map(() => 0),
    createdAt: new Date(),
  }
  polls.push(poll)
  return poll
}

export function votePoll(id: string, optionIndex: number): Poll | undefined {
  const poll = polls.find((p) => p.id === id)
  if (poll && optionIndex >= 0 && optionIndex < poll.options.length) {
    poll.votes[optionIndex]++
  }
  return poll
}
