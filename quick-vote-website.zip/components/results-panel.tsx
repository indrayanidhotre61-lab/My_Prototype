"use client"

import { useSearchParams } from "next/navigation"
import useSWR from "swr"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Loader2, ArrowRight, Trophy, RefreshCw, Users } from "lucide-react"
import Link from "next/link"
import { cn } from "@/lib/utils"

interface Poll {
  id: string
  question: string
  options: string[]
  votes: number[]
}

const fetcher = (url: string) => fetch(url).then((res) => res.json())

function ResultCard({ poll }: { poll: Poll }) {
  const totalVotes = poll.votes.reduce((sum, v) => sum + v, 0)
  const maxVotes = Math.max(...poll.votes)

  return (
    <Card>
      <CardHeader>
        <div className="flex items-start justify-between gap-4">
          <div>
            <CardTitle className="text-lg">{poll.question}</CardTitle>
            <CardDescription className="mt-1 flex items-center gap-1.5">
              <Users className="size-3.5" />
              {totalVotes} {totalVotes === 1 ? "vote" : "votes"} total
            </CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col gap-4">
          {poll.options.map((option, index) => {
            const percentage =
              totalVotes > 0
                ? Math.round((poll.votes[index] / totalVotes) * 100)
                : 0
            const isWinner = poll.votes[index] === maxVotes && maxVotes > 0

            return (
              <div key={index} className="flex flex-col gap-1.5">
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-2">
                    {isWinner && (
                      <Trophy className="size-3.5 text-primary" />
                    )}
                    <span
                      className={cn(
                        "font-medium",
                        isWinner ? "text-primary" : "text-foreground"
                      )}
                    >
                      {option}
                    </span>
                  </div>
                  <span className="tabular-nums text-muted-foreground">
                    {poll.votes[index]} ({percentage}%)
                  </span>
                </div>
                <Progress
                  value={percentage}
                  className={cn("h-3", isWinner && "[&>div]:bg-primary")}
                />
              </div>
            )
          })}
        </div>
      </CardContent>
    </Card>
  )
}

export function ResultsPanel() {
  const searchParams = useSearchParams()
  const pollId = searchParams.get("poll")

  const {
    data: polls,
    isLoading,
    mutate,
  } = useSWR<Poll[]>("/api/polls", fetcher, {
    refreshInterval: 5000,
  })

  if (isLoading) {
    return (
      <div className="flex flex-col items-center gap-3 py-20">
        <Loader2 className="size-8 animate-spin text-primary" />
        <p className="text-sm text-muted-foreground">Loading results...</p>
      </div>
    )
  }

  const filteredPolls = pollId ? polls?.filter((p) => p.id === pollId) : polls

  if (!filteredPolls || filteredPolls.length === 0) {
    return (
      <div className="mx-auto max-w-lg">
        <div className="mb-8 text-center">
          <h1 className="text-2xl font-bold tracking-tight text-foreground md:text-3xl">
            Results
          </h1>
          <p className="mt-2 text-muted-foreground">
            No results to show yet. Create a poll and start voting!
          </p>
        </div>
        <div className="text-center">
          <Link href="/create">
            <Button className="gap-2">
              Create a Poll
              <ArrowRight className="size-4" />
            </Button>
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="mx-auto max-w-lg">
      <div className="mb-8 flex flex-col items-center gap-4 text-center sm:flex-row sm:justify-between sm:text-left">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-foreground md:text-3xl">
            Results
          </h1>
          <p className="mt-1 text-muted-foreground">
            Live poll results auto-refresh every 5 seconds.
          </p>
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={() => mutate()}
          className="shrink-0 gap-1.5"
        >
          <RefreshCw className="size-3.5" />
          Refresh
        </Button>
      </div>

      <div className="flex flex-col gap-6">
        {filteredPolls.map((poll) => (
          <ResultCard key={poll.id} poll={poll} />
        ))}
      </div>
    </div>
  )
}
