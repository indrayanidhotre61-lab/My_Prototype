import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight, Zap, Users, Clock, CheckCircle2 } from "lucide-react"

export function HeroSection() {
  return (
    <section className="relative overflow-hidden pb-16 pt-12 md:pb-24 md:pt-20">
      {/* Background decoration */}
      <div className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute -top-24 right-0 h-72 w-72 rounded-full bg-primary/5 blur-3xl" />
        <div className="absolute bottom-0 left-0 h-56 w-56 rounded-full bg-primary/8 blur-3xl" />
      </div>

      <div className="mx-auto max-w-5xl px-4 md:px-6">
        {/* Badge */}
        <div className="mb-6 flex justify-center">
          <div className="inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/5 px-4 py-1.5 text-sm font-medium text-primary">
            <Zap className="size-3.5" />
            Built for College Students
          </div>
        </div>

        {/* Headline */}
        <div className="mx-auto max-w-2xl text-center">
          <h1 className="text-balance text-4xl font-bold tracking-tight text-foreground md:text-5xl lg:text-6xl">
            Group Decisions,
            <span className="text-primary"> Made Faster</span>
          </h1>
          <p className="mx-auto mt-5 max-w-lg text-pretty text-base leading-relaxed text-muted-foreground md:text-lg">
            Stop wasting time in messy group chats. Create a poll, share the
            link, and get a clear answer in minutes.
          </p>

          {/* CTA */}
          <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <Link href="/create">
              <Button size="lg" className="gap-2 px-8 text-base font-semibold">
                Create a Poll
                <ArrowRight className="size-4" />
              </Button>
            </Link>
            <Link href="/vote">
              <Button
                variant="outline"
                size="lg"
                className="gap-2 px-8 text-base font-semibold"
              >
                Vote Now
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  )
}

export function ProblemSection() {
  return (
    <section className="border-t border-border bg-card py-16 md:py-20">
      <div className="mx-auto max-w-5xl px-4 md:px-6">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-balance text-2xl font-bold tracking-tight text-foreground md:text-3xl">
            The Problem
          </h2>
          <p className="mt-3 text-pretty leading-relaxed text-muted-foreground">
            Making group decisions in college is painfully slow. Endless
            discussions in chat groups, unorganized classroom debates, and
            nobody ever agrees on anything.
          </p>
        </div>

        <div className="mt-12 grid gap-4 sm:grid-cols-3">
          {[
            {
              icon: Clock,
              title: "Time Wasting",
              description:
                "Hours spent scrolling through group chat messages just to decide where to eat.",
            },
            {
              icon: Users,
              title: "No Structure",
              description:
                "Everyone talks over each other and good ideas get lost in the noise.",
            },
            {
              icon: CheckCircle2,
              title: "No Clear Outcome",
              description:
                "Discussions end without a final decision because nobody tracks the votes.",
            },
          ].map((item) => (
            <div
              key={item.title}
              className="rounded-xl border border-border bg-background p-6"
            >
              <div className="mb-3 flex size-10 items-center justify-center rounded-lg bg-destructive/10">
                <item.icon className="size-5 text-destructive" />
              </div>
              <h3 className="font-semibold text-foreground">{item.title}</h3>
              <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">
                {item.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

export function SolutionSection() {
  return (
    <section className="py-16 md:py-20">
      <div className="mx-auto max-w-5xl px-4 md:px-6">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-balance text-2xl font-bold tracking-tight text-foreground md:text-3xl">
            The Solution
          </h2>
          <p className="mt-3 text-pretty leading-relaxed text-muted-foreground">
            QuickVote gives your group a simple, structured way to make
            decisions. Three easy steps and you have a clear winner.
          </p>
        </div>

        <div className="mt-12 grid gap-6 sm:grid-cols-3">
          {[
            {
              step: "01",
              title: "Create a Poll",
              description:
                "Write your question and add the options your group needs to choose from.",
            },
            {
              step: "02",
              title: "Share & Vote",
              description:
                "Share the poll with your group. Everyone picks their favorite option.",
            },
            {
              step: "03",
              title: "See Results",
              description:
                "Results update in real-time with clear progress bars showing the winner.",
            },
          ].map((item) => (
            <div
              key={item.step}
              className="group rounded-xl border border-border bg-card p-6 transition-colors hover:border-primary/30"
            >
              <span className="text-3xl font-bold text-primary/20 transition-colors group-hover:text-primary/40">
                {item.step}
              </span>
              <h3 className="mt-3 font-semibold text-foreground">
                {item.title}
              </h3>
              <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">
                {item.description}
              </p>
            </div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <Link href="/create">
            <Button size="lg" className="gap-2 px-8 text-base font-semibold">
              Get Started
              <ArrowRight className="size-4" />
            </Button>
          </Link>
        </div>
      </div>
    </section>
  )
}
