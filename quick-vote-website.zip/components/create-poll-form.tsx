"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { PlusCircle, Trash2, Send, Loader2 } from "lucide-react"

export function CreatePollForm() {
  const router = useRouter()
  const [question, setQuestion] = useState("")
  const [options, setOptions] = useState(["", ""])
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [error, setError] = useState("")

  const addOption = () => {
    if (options.length < 6) {
      setOptions([...options, ""])
    }
  }

  const removeOption = (index: number) => {
    if (options.length > 2) {
      setOptions(options.filter((_, i) => i !== index))
    }
  }

  const updateOption = (index: number, value: string) => {
    const newOptions = [...options]
    newOptions[index] = value
    setOptions(newOptions)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")

    const trimmedQuestion = question.trim()
    const trimmedOptions = options.map((o) => o.trim()).filter((o) => o !== "")

    if (!trimmedQuestion) {
      setError("Please enter a question.")
      return
    }
    if (trimmedOptions.length < 2) {
      setError("Please add at least 2 options.")
      return
    }

    setIsSubmitting(true)
    try {
      const res = await fetch("/api/polls", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          question: trimmedQuestion,
          options: trimmedOptions,
        }),
      })
      const poll = await res.json()
      router.push(`/vote?poll=${poll.id}`)
    } catch {
      setError("Something went wrong. Please try again.")
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="mx-auto max-w-lg">
      <div className="mb-8 text-center">
        <h1 className="text-2xl font-bold tracking-tight text-foreground md:text-3xl">
          Create a Poll
        </h1>
        <p className="mt-2 text-muted-foreground">
          Ask your group a question and let them decide.
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>New Poll</CardTitle>
          <CardDescription>
            Add your question and provide at least 2 options.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="flex flex-col gap-5">
            <div className="flex flex-col gap-2">
              <Label htmlFor="question" className="font-medium">
                Question
              </Label>
              <Input
                id="question"
                placeholder="e.g. Where should we eat tonight?"
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                className="h-11"
              />
            </div>

            <div className="flex flex-col gap-3">
              <Label className="font-medium">Options</Label>
              {options.map((option, index) => (
                <div key={index} className="flex items-center gap-2">
                  <div className="flex size-7 shrink-0 items-center justify-center rounded-md bg-primary/10 text-xs font-semibold text-primary">
                    {String.fromCharCode(65 + index)}
                  </div>
                  <Input
                    placeholder={`Option ${index + 1}`}
                    value={option}
                    onChange={(e) => updateOption(index, e.target.value)}
                    className="h-10"
                  />
                  {options.length > 2 && (
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon-sm"
                      onClick={() => removeOption(index)}
                      className="shrink-0 text-muted-foreground hover:text-destructive"
                      aria-label={`Remove option ${index + 1}`}
                    >
                      <Trash2 className="size-4" />
                    </Button>
                  )}
                </div>
              ))}

              {options.length < 6 && (
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={addOption}
                  className="mt-1 w-full gap-1.5"
                >
                  <PlusCircle className="size-4" />
                  Add Option
                </Button>
              )}
            </div>

            {error && (
              <p className="text-sm font-medium text-destructive" role="alert">
                {error}
              </p>
            )}

            <Button
              type="submit"
              size="lg"
              disabled={isSubmitting}
              className="mt-2 gap-2 font-semibold"
            >
              {isSubmitting ? (
                <Loader2 className="size-4 animate-spin" />
              ) : (
                <Send className="size-4" />
              )}
              {isSubmitting ? "Creating..." : "Create Poll"}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
