"use client"

import { useEffect, useState } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import useSWR from "swr"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
  CardFooter,
} from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Check, Loader2, Vote, ArrowRight } from "lucide-react"
import Link from "next/link"
import { cn } from "@/lib/utils"

interface Poll {
  id: string
  question: string
  options: string[]
  votes: number[]
}

const fetcher = (url: string) => fetch(url).then((res) => res.json())

function PollCard({ poll }: { poll: Poll }) {
  const router = useRouter()
  const [selected, setSelected] = useState<string | undefined>()
  const [submitted, setSubmitted] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleVote = async () => {
    if (selected === undefined) return
    setIsSubmitting(true)
    try {
      await fetch(`/api/polls/${poll.id}/vote`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ optionIndex: parseInt(selected) }),
      })
      setSubmitted(true)
    } catch {
      // handle error
    } finally {
      setIsSubmitting(false)
    }
  }

  if (submitted) {
    return (
      <Card className="border-primary/20">
        <CardContent className="flex flex-col items-center gap-4 py-10">
          <div className="flex size-14 items-center justify-center rounded-full bg-primary/10">
            <Check className="size-7 text-primary" />
          </div>
          <div className="text-center">
            <h3 className="text-lg font-semibold text-foreground">
              Vote Submitted!
            </h3>
            <p className="mt-1 text-sm text-muted-foreground">
              Your vote has been recorded successfully.
            </p>
          </div>
          <Link href={`/results?poll=${poll.id}`}>
            <Button variant="outline" className="mt-2 gap-2">
              View Results
              <ArrowRight className="size-4" />
            </Button>
          </Link>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">{poll.question}</CardTitle>
        <CardDescription>
          Select one option and submit your vote.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <RadioGroup value={selected} onValueChange={setSelected}>
          {poll.options.map((option, index) => (
            <Label
              key={index}
              htmlFor={`${poll.id}-${index}`}
              className={cn(
                "flex cursor-pointer items-center gap-3 rounded-lg border border-border bg-background p-4 transition-colors hover:bg-accent/50",
                selected === String(index) &&
                  "border-primary/40 bg-primary/5 hover:bg-primary/5"
              )}
            >
              <RadioGroupItem
                value={String(index)}
                id={`${poll.id}-${index}`}
              />
              <span className="text-sm font-medium text-foreground">
                {option}
              </span>
            </Label>
          ))}
        </RadioGroup>
      </CardContent>
      <CardFooter>
        <Button
          onClick={handleVote}
          disabled={selected === undefined || isSubmitting}
          className="w-full gap-2 font-semibold"
          size="lg"
        >
          {isSubmitting ? (
            <Loader2 className="size-4 animate-spin" />
          ) : (
            <Vote className="size-4" />
          )}
          {isSubmitting ? "Submitting..." : "Submit Vote"}
        </Button>
      </CardFooter>
    </Card>
  )
}

export function VotePanel() {
  const searchParams = useSearchParams()
  const pollId = searchParams.get("poll")

  const { data: polls, isLoading } = useSWR<Poll[]>("/api/polls", fetcher)

  if (isLoading) {
    return (
      <div className="flex flex-col items-center gap-3 py-20">
        <Loader2 className="size-8 animate-spin text-primary" />
        <p className="text-sm text-muted-foreground">Loading polls...</p>
      </div>
    )
  }

  const filteredPolls = pollId
    ? polls?.filter((p) => p.id === pollId)
    : polls

  if (!filteredPolls || filteredPolls.length === 0) {
    return (
      <div className="mx-auto max-w-lg">
        <div className="mb-8 text-center">
          <h1 className="text-2xl font-bold tracking-tight text-foreground md:text-3xl">
            Vote
          </h1>
          <p className="mt-2 text-muted-foreground">
            No polls available yet. Create one first!
          </p>
        </div>
        <div className="text-center">
          <Link href="/create">
            <Button className="gap-2">
              Create a Poll
              <ArrowRight className="size-4" />
            </Button>
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="mx-auto max-w-lg">
      <div className="mb-8 text-center">
        <h1 className="text-2xl font-bold tracking-tight text-foreground md:text-3xl">
          Vote
        </h1>
        <p className="mt-2 text-muted-foreground">
          {pollId
            ? "Cast your vote on this poll."
            : "Pick a poll and cast your vote."}
        </p>
      </div>

      <div className="flex flex-col gap-6">
        {filteredPolls.map((poll) => (
          <PollCard key={poll.id} poll={poll} />
        ))}
      </div>
    </div>
  )
}
