import { NextResponse } from "next/server"
import { getPolls, createPoll } from "@/lib/poll-store"

export async function GET() {
  return NextResponse.json(getPolls())
}

export async function POST(request: Request) {
  const body = await request.json()
  const { question, options } = body

  if (!question || !options || options.length < 2) {
    return NextResponse.json(
      { error: "Question and at least 2 options are required" },
      { status: 400 }
    )
  }

  const poll = createPoll(question, options)
  return NextResponse.json(poll, { status: 201 })
}
