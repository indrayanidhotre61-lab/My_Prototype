import { NextResponse } from "next/server"
import { votePoll } from "@/lib/poll-store"

export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params
  const body = await request.json()
  const { optionIndex } = body

  if (typeof optionIndex !== "number") {
    return NextResponse.json(
      { error: "optionIndex is required" },
      { status: 400 }
    )
  }

  const poll = votePoll(id, optionIndex)
  if (!poll) {
    return NextResponse.json({ error: "Poll not found" }, { status: 404 })
  }

  return NextResponse.json(poll)
}
