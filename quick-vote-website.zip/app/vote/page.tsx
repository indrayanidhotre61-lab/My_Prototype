import { Suspense } from "react"
import { VotePanel } from "@/components/vote-panel"
import { Loader2 } from "lucide-react"

function VoteFallback() {
  return (
    <div className="flex flex-col items-center gap-3 py-20">
      <Loader2 className="size-8 animate-spin text-primary" />
      <p className="text-sm text-muted-foreground">Loading polls...</p>
    </div>
  )
}

export default function VotePage() {
  return (
    <main className="py-10 md:py-16">
      <Suspense fallback={<VoteFallback />}>
        <VotePanel />
      </Suspense>
    </main>
  )
}
