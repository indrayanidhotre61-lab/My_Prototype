import type { Metadata, Viewport } from 'next'
import { Inter, Space_Grotesk } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import { Navbar } from '@/components/navbar'
import './globals.css'

const _inter = Inter({ subsets: ["latin"], variable: "--font-inter" })
const _spaceGrotesk = Space_Grotesk({ subsets: ["latin"], variable: "--font-space-grotesk" })

export const metadata: Metadata = {
  title: 'QuickVote - Group Decisions Made Faster',
  description: 'QuickVote helps college students make group decisions faster with simple, real-time polls. Stop arguing in group chats and start voting.',
  generator: 'v0.app',
  icons: {
    icon: [
      {
        url: '/icon-light-32x32.png',
        media: '(prefers-color-scheme: light)',
      },
      {
        url: '/icon-dark-32x32.png',
        media: '(prefers-color-scheme: dark)',
      },
      {
        url: '/icon.svg',
        type: 'image/svg+xml',
      },
    ],
    apple: '/apple-icon.png',
  },
}

export const viewport: Viewport = {
  themeColor: '#2563EB',
  userScalable: true,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body className={`${_inter.variable} ${_spaceGrotesk.variable} font-sans antialiased`}>
        <Navbar />
        <div className="min-h-[calc(100vh-4rem)]">
          {children}
        </div>
        <footer className="border-t border-border bg-card py-6">
          <div className="mx-auto max-w-5xl px-4 text-center text-sm text-muted-foreground md:px-6">
            QuickVote — A College Project Prototype
          </div>
        </footer>
        <Analytics />
      </body>
    </html>
  )
}
