import { CreatePollForm } from "@/components/create-poll-form"

export default function CreatePage() {
  return (
    <main className="py-10 md:py-16">
      <CreatePollForm />
    </main>
  )
}
