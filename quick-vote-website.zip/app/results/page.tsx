import { Suspense } from "react"
import { ResultsPanel } from "@/components/results-panel"
import { Loader2 } from "lucide-react"

function ResultsFallback() {
  return (
    <div className="flex flex-col items-center gap-3 py-20">
      <Loader2 className="size-8 animate-spin text-primary" />
      <p className="text-sm text-muted-foreground">Loading results...</p>
    </div>
  )
}

export default function ResultsPage() {
  return (
    <main className="py-10 md:py-16">
      <Suspense fallback={<ResultsFallback />}>
        <ResultsPanel />
      </Suspense>
    </main>
  )
}
