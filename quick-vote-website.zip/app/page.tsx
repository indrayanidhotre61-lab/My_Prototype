import {
  HeroSection,
  ProblemSection,
  SolutionSection,
} from "@/components/hero-section"

export default function HomePage() {
  return (
    <main>
      <HeroSection />
      <ProblemSection />
      <SolutionSection />
    </main>
  )
}
